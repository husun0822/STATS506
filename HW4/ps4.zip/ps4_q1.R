#### Coding for PS4_Q1, SQL query using dbplyr package in R ####

## Read the relational database
lahman = lahman_sqlite()

## Create a new table called alltime_hitter:

alltime_hitter = lahman %>%
  tbl(sql('
          SELECT m.nameFirst || " " || m.nameLast AS Player,m.debut AS Debut,m.birthCountry AS "Country of Birth",Hits
          FROM master m
          LEFT JOIN
          (
          SELECT playerID, sum(H) AS Hits
          FROM batting
          GROUP BY playerID
          ) b
          ON m.playerID = b.playerID
          WHERE birthCountry IS NOT NULL
          GROUP BY birthCountry
          HAVING Hits == max(Hits) AND Hits >= 200
          ORDER BY -Hits
          ')) %>% collect()

print(alltime_hitter,n=nrow(alltime_hitter))